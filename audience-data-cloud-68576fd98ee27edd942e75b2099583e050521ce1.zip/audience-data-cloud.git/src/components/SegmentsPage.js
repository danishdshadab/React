import React from 'react'
import {
	Box,
	Grid,
	Button,
	IconButton,
	Input,
	InputAdornment,
	Typography,
	Table,
	TableHead,
	TableBody,
	TableRow,
	TableCell,
	TableSortLabel,
	Popover,
	Modal,
	List,
	ListItem,
	ListItemIcon,
	CircularProgress
} from '@material-ui/core';
import {
	Search,
	MoreVert,
	GetApp,
	Edit,
	Delete
} from '@material-ui/icons';
import ADCHeader from './ADCHeader';
import { useQuery } from '@apollo/react-hooks';
import gql from 'graphql-tag';

import {baseUrl, ATTR_VAL_ID_SPLIT_STRING, KRUX_SEGMENT_FIELD_NAME} from './../constants';
import {getAttributeFromFilter} from '../helpers';
let segments = [];
let rulIdx = 0;
let loadingData = true;

const query_segdef = gql(`
	{
		SegmentDefinitions {
			id
			name
			category
			rule
			gam_audience_id
			population {
				calculated_on
				calculated_population
			}
			modified_on
		}
	}
`);


export default function SegmentsPage(props) {
	const [searchText, setSearchText] = React.useState("");
	const [anchorEl, setAnchorEl] = React.useState(null);
	const [searchResults, setSearchResults] = React.useState(segments);
	const [currentRules, setCurrentRules] = React.useState(null);
	const [selectedID, setSelectedID] = React.useState(null);
	const [sortBy, setSortBy] = React.useState("");
	const [sortDirection, setSortDirection] = React.useState("asc");
	const tableFields = ["Name", "Rules", "Last modified", "Population", "Category", "DFP Id"];


	const filterNames = {};
	for (let at in props.data) {
		for (let a in props.data[at]) {
			filterNames[a] = props.data[at][a].filter_name;
		}
	}
	
	const getRulesFromSegment = (s) => {
		let rul = [];
		if(s.rule){
		let segmentRule = JSON.parse(s.rule);
		let parsedRule = {...segmentRule['filter']['where'], ...segmentRule['filter']['having']}

		for (let subidx in parsedRule) {
			const attrib = getAttributeFromFilter(subidx, filterNames);
			for (let op in parsedRule[subidx]) {
				let values = [];
				let ruleValues = parsedRule[subidx][op];
				//As krux has the ||||| separator in its values, we need to find the correct rule by using includes(...)
				if(subidx.toLowerCase() === KRUX_SEGMENT_FIELD_NAME) {
					values = ruleValues.map(v => props.data['User']['Krux Segment'].field_values.filter(dv => dv.includes(v))[0])
				} else {
					values = Array.isArray(ruleValues) ? ruleValues : [ruleValues]
				}
				rul.push({
					index: ++rulIdx,
					attribute: attrib,
					filterName: subidx,
					operator: op,
					values
				});
			}
		}
		return rul;
	} else {
		return null
	}
	}
	

	const searchChanged = event => {
		const val = event.target.value;
		setSearchText(val);
		setSearchResults(segments.filter(seg => {
			// return seg.name.toLowerCase().indexOf(val.toLowerCase()) !== -1 || 
			// seg.category.toLowerCase().indexOf(val.toLowerCase()) !== -1 ||
			// seg.gam_audience_id.toLowerCase().indexOf(val.toLowerCase()) !== -1;
			return JSON.stringify(seg).indexOf(val.toLowerCase()) !== -1
		}));
		setSortBy("");
	}
	const moreClicked = (event, segID) => {
		setAnchorEl(event.currentTarget);
		setSelectedID(segID);
	}
	const popClosed = () => {
		setAnchorEl(null);
	}
	const formatDate = ds => {
		return ds.substr(0, 19);
	}
	const formatPopulation = p => {
		if (p >= 1000000000) {
			return Math.floor(p / 100000000)/10 + "b";
		} else if (p >= 1000000) {
			return Math.floor(p / 100000)/10 + "m";
		} else if (p >= 1000) {
			return Math.floor(p / 100)/10 + "k";
		}
		return p;
	}

	/**
	 * Build a query body from json by iteratively parse through its content
	 * 
	 * Note that, as the input originally is a json object for sure, the string return 
	 *   based on the logic will have '{' and '}' on both end, which is not accepted by 
	 *   graphQL, this could be addressed easily by slicing the string in the parent call.
	 * @param {JSON} rule_input 
	 */
	const createQueryFromRule = (objectInput) => {
		let inputType = typeof(objectInput);
		switch (inputType) {
			// if input is a number, just return it as a number
			case "number":
				return objectInput;
			// if input is a string, return it as a string with double quotes 
			case "string":
				return "\"" + objectInput + "\"";
			// if input is an object, then it could be a string or an array
			case "object":
				if(Array.isArray(objectInput)){
					// if input is an array, first add brackets at both end, and then iter through its elements,
					//  and finally join them using comma.
					return '[' + objectInput.map(element => createQueryFromRule(element,'')).join(',') + ']';
				} else {
					// if input is an object, usually a json object, iterate through is key,
					//   and for each key parse it, and join the result using comma.
					let keys = Object.keys(objectInput);
					return "{" + 
								keys.map(key => 
									{return key + ": " + createQueryFromRule(objectInput[key])}).join(',') 
								+ "}"
				}
			// if there's nothing, return an empty string
			default:
				return ''
		}
	}

    /**
	 * A helper function to handle the create of the uri query.
	 * @param {String} query_input The rule field of a segment object
	 */
	const generateAdcUidFileQuery = query_input => {
		const ruleParsed = createQueryFromRule(JSON.parse(query_input))
		// slicing the rule to exclude brackets on both end
		let selectedRule = ruleParsed.slice(1, ruleParsed.length - 1);
		return "{ q1: AdcUidFile(" + selectedRule + ")}"
	}
	/**
	 * Async function handles the download csv event
	 * @param {Object} segment 
	 * 	an array contain the selected segment created by [...].filter(..) in DOM,
	 */
	async function exportCSVClicked(segment){
		const selectedSegment = segment[0];
		// graphql seems not accept single quote, but only double quotes.
		const selectedRule = generateAdcUidFileQuery(selectedSegment.rule);
		const payload = {
			method: "POST",
			headers: {"Content-Type": "application/json"},
			body: JSON.stringify({query: selectedRule})
		}
		try {
			let response = await fetch(baseUrl, payload);
			let jsonReturned = await response.json();
			let uriReturned = jsonReturned.data.q1;
			window.open(uriReturned);
		} catch(e) {
			console.log("error: " + e.toString());
		}
		setAnchorEl(null);
	}
	const editSegmentClicked = (id) => {
		window.location.href = "/edit/" + id;
	}
	const deleteSegmentClicked = (id) => {
		const mutation = `
			mutation DeleteSegment {
				DeleteSegmentDefinitionById(
					id: "` + id + `"
				)
			}
		`;
		const url = baseUrl;
		const opts = {
			method: "POST",
			headers: { "Content-Type": "application/json" },
			body: JSON.stringify({ query: mutation })
		};
		fetch(url, opts)
			.then(() => {
				window.location.href = "/SegmentsPage";
			})
			.catch(e => {
				console.log("Delete error : " + e);
			})
	}
	const viewAllRules = (rules) => {
		setCurrentRules(rules);
	}
	const modalClose = () => {
		setCurrentRules(null);
	}
	const sort = col => {
		if (col === "" || col === null) {
			return;
		}
		let newDir = "asc";
		if (sortBy === col) {
			newDir = sortDirection === "asc" ? "desc" : "asc";
			setSortDirection(newDir);
		} else {
			setSortBy(col);
			setSortDirection("asc");
		}
		if (col === "Name") {
			searchResults.sort((a, b) => {
				const ret = a.name.localeCompare(b.name);
				return newDir === "asc" ? ret : -ret;
			});
		} else if (col === "Rules") {
			searchResults.sort((a, b) => {
				const ret = a.rules.length - b.rules.length;
				return newDir === "asc" ? ret : -ret;
			});
		} else if (col === "Last modified") {
			searchResults.sort((a, b) => {
				const ret = a.modified_on.localeCompare(b.last_modified);
				return newDir === "asc" ? ret : -ret;
			});
		} else if (col === "Population") {
			searchResults.sort((a, b) => {
				const ret = a.population - b.population;
				return newDir === "asc" ? ret : -ret;
			});
		} else if (col === "Category") {
			searchResults.sort((a, b) => {
				const ret = a.category.localeCompare(b.category);
				return newDir === "asc" ? ret : -ret;
			});
		}
	}
	const { data: segData, loading: segLoading, error: segError } = useQuery(query_segdef, {fetchPolicy: 'network-only'});

	if (segLoading) {
		return(
			<div>
				<div style={{margin: "auto", height: 40, width: 40, marginTop: 300, marginBottom: 16}}>
					<CircularProgress style={{margin: "auto"}} />
				</div>
				<Typography align="center">Loading ...</Typography>
			</div>
		);
	};

	if (segError) {
		return(
			<div style={{marginTop: 350}}>
				<Typography align="center">Error</Typography>
			</div>
		);
	};

	if (loadingData) {
		segments = segData.SegmentDefinitions;
		console.log(segData)
		for (let idx in segments) {
			segments[idx].rules = getRulesFromSegment(segments[idx]) || "";
			segments[idx].last_modified = segments[idx].modified_on;
			segments[idx].population = Number(segments[idx].population.calculated_population);
			segments[idx].gam_audience_id =segments[idx].gam_audience_id || "undefined" ;
		}
		setSearchResults(segments);
		loadingData = false;
	}

	return (
		<Box>
			<ADCHeader viewContext={'segmentlist'}/>
			<Grid
				style={{padding: "10px", height: '100vh', marginTop: "80px"}}
			>
				<Grid container direction="row" style={{marginBottom: "15px"}}>
					<Grid item xs={10}>
						<Typography  variant="h6">Segments</Typography>
					</Grid>
					<Grid item xs={2}>
						<Input
							id="search"
							value={searchText}
							onChange={searchChanged}
							placeholder="Search values..."
							endAdornment={
								<InputAdornment position="end">
									<Search/>
								</InputAdornment>
							}
						/>
					</Grid>
				</Grid>
				<Grid item>
					<Table>
						<TableHead>
							<TableRow>
							{
								tableFields.map(field => (
									<TableCell key={field} align="left">
										<TableSortLabel
											active={sortBy === field}
											direction={sortDirection}
											onClick={event => sort(field)}
										>
											{field}
										</TableSortLabel>
									</TableCell>
								))
							}
								<TableCell></TableCell>
								<TableCell></TableCell>
							</TableRow>
						</TableHead>
						<TableBody>
							{searchResults.map(seg => {
								return(
								<TableRow key={seg.id}>
									<TableCell align="left">{seg.name}</TableCell>
									<TableCell align="left">
										{
											(seg.rules.length === 1) ? (
												<Typography variant="caption">
													<strong>{seg.rules[0].attribute + " "}</strong>
													{seg.rules[0].operator}
													<strong>{" " + 
													seg.rules[0].values.map(v => isNaN(v) ? v.split(ATTR_VAL_ID_SPLIT_STRING)[0] : v)}</strong>
												</Typography>
											) : (
												<Grid
													container
													direction="column"
												>
												    {
														seg.rules ?
														<Typography variant="caption">
															<strong>{seg.rules[0].attribute + " "}</strong>
															{seg.rules[0].operator}
															<strong>{" " + seg.rules[0].values.map(v => isNaN(v) ? v.split(ATTR_VAL_ID_SPLIT_STRING)[0] : v)}</strong>
															&nbsp;+{seg.rules.length - 1} other values
														</Typography>:
														<Typography>Rules Undefined</Typography>
													}

													<Button
														variant="outlined"
														size="small"
														style={{padding: "0"}}
														onClick={event => viewAllRules(seg.rules)}
													>
														<Typography variant="caption">
															View all rules
														</Typography>
													</Button>
												</Grid>
											)
										}
									</TableCell>
									<TableCell align="left">{formatDate(seg.last_modified)}</TableCell>
									<TableCell align="left">{formatPopulation(seg.population)}</TableCell>
									<TableCell align="left">{seg.category}</TableCell>

									<TableCell align="left">
										{/** DFP Button, it will probably be replace by an indicator: */}
										{/* <Button disabled variant="outlined">
											Publish to DFP
										</Button> */}
										{seg.gam_audience_id || "undefined"}
									</TableCell>
									<TableCell>
										<IconButton onClick={event => moreClicked(event, seg.id)}>
											<MoreVert/>
										</IconButton>
									</TableCell>

								</TableRow>)
							})}
						</TableBody>
					</Table>
				</Grid>
			</Grid>

			<Popover
				open={Boolean(anchorEl)}
				anchorEl={anchorEl}
				onClose={popClosed}
			>
			{selectedID === null ? null : (
				<Box style={{borderStyle: 'solid', borderWidth: 1, borderColor: 'lightgray'}}>
					<List>
						<ListItem button onClick={event => exportCSVClicked(segments.filter(segment => segment.id === selectedID))}>
							<ListItemIcon>
								<GetApp/>
							</ListItemIcon>
							<Typography variant="body2">Export .CSV</Typography>
						</ListItem>
						<ListItem button onClick={event => editSegmentClicked(selectedID)}>
							<ListItemIcon>
								<Edit/>
							</ListItemIcon>
							<Typography variant="body2">Edit segment</Typography>
						</ListItem>
						<ListItem button onClick={event => deleteSegmentClicked(selectedID)}>
							<ListItemIcon>
								<Delete/>
							</ListItemIcon>
							<Typography variant="body2">Delete segment</Typography>
						</ListItem>
					</List>
				</Box>
			)}		
			</Popover>
            {/**The modal for showing all rules */}
			<Modal
				open={currentRules !== null}
				onClose={modalClose}
			>
				<Box style={{borderStyle: 'solid', borderWidth: 1, borderColor: 'lightgray', textAlign: "center", width: "400px", position: "absolute", left: "50%", top: "50%", padding: "16px", marginLeft: "-200px", marginTop: "-100px", background: 'white'}}>
					{currentRules === null ? (<Typography>No rules</Typography>) : (
						currentRules.map(rule => (
							<Typography key={rule.index} variant="caption">
								<strong>{rule.attribute + " "}</strong>
								{rule.operator}
								<strong>{" " + rule.values.map(v => isNaN(v) ? v.split(ATTR_VAL_ID_SPLIT_STRING)[0] : v)}</strong>
								<br/>
							</Typography>
						))
					)}
				</Box>
			</Modal>
		</Box>
	)
}