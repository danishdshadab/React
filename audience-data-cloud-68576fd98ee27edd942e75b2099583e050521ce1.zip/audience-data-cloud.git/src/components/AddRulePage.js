import React from 'react';
import {
	Grid,
	Box,
	Typography,
	Button,
	MenuItem,
	Input,
	TextField,
	IconButton,
	Modal
} from '@material-ui/core';
import {
	Edit,
	Home,
} from '@material-ui/icons';
import ADCHeader from './ADCHeader';
import { useQuery } from '@apollo/react-hooks';
import gql from 'graphql-tag';
import {
	baseUrl, 
	ATTR_VAL_ID_SPLIT_STRING, 
	SEG_CAT,
	TOTAL_POP_QUERY
} from './../constants';
import CancelIcon from '@material-ui/icons/Cancel';
import {AudienceAttributes, AttributeValues, Loading, DayRangePicker, CountDisplay} from './../subcomponents';
import {getAttributeFromFilter} from './../helpers';
import Autocomplete from '@material-ui/lab/Autocomplete';

/**
 * Some contants used in future.
 */
const attTypes = [];
const attributes = {};
const filterNames = {};
const filterTypes = {};
const attDataTypes = {};

const segmentDefinitionsQuery = gql(`
		{
			SegmentDefinitions {
				id
				name
				is_active
				category
				rule
				description
				gam_audience_id
				population {
					calculated_on
					calculated_population
				}
			}
		}
	`);
/**
 * Define operator mapping, if an operator does not exist in this map, use the operator itself.
 */
const ops = {
	"<": "LT",
	"<=": "LTE",
	"=": "EQ",
	"<>": "NE",
	"NOT IN": "NIN",
	"IN": "IN",
	">": "GT",
	">=": "GTE"
};

/**
 * For each rule added to the 'Rules' panel, it will be assigned a unique id by incrementing
 *   prevRuleIndex everytime a new rule inserted.
 */
let prevRuleIndex = 0;

let rulesFromList = [];
let editMode = -1; // -1: no, 0: loading, 1: yes

// This function accepts a second level menu item name / attribute name and returns the top level menu item name / attribute name
// ex. Site Section --> Web Interaction
function getAttributeType(att) {
	for (let typ in attTypes) {
		if (attributes[attTypes[typ]].indexOf(att) >= 0) {
			return attTypes[typ];
		}
	}
	return att;
}

// This function accepts a second level menu item name / attribute name and returns the filter type (ex. Having, Where, etc.)
function getFilterTypeFromName(fil) {
	try {
		return filterTypes[fil]
	}
	catch (err) {
		console.log("No such filter type : " + fil);
		return fil;
	}
}

// This function accepts a second level menu item name / attribute name and returns the attribute data type (ex. string, integer, etc.)
function getDataTypeFromName(fil) {
	try {
		return attDataTypes[fil]
	}
	catch (err) {
		console.log("No such data type : " + fil);
		return fil;
	}
}

let population = 0;

// This function accepts the rules (as formatted by the front-end) and formats them into the filter component of a valid GraphQL query.
function prepQueryFilter(rules, days) {
	let havingFilter;
	let havingRules = [];
	let whereFilter;
	let whereRules = [];
	let queryFilter = ``;
	if (rules.length > 0) {
		for (let i in rules) {
			let f_vals;
			if (rules[i].dataType === 'string') {
				f_vals = rules[i].values.map((i) => {
					return `"` + (isNaN(i) && i.includes(ATTR_VAL_ID_SPLIT_STRING) ? i.split(ATTR_VAL_ID_SPLIT_STRING)[1] : i) + `"` 
				}).join(',');
			} else {
				f_vals = rules[i].values.map((i) => {
					return i
				}).join(',');
			}
			if (rules[i].values.length > 1) {
				f_vals = `[` + f_vals + `]`;
			}
			if (rules[i].filterType === 'having') {
				//Having rules here
				havingRules.push(`${rules[i].filterName}: {${ops[rules[i].operator] === undefined ? rules[i].operator : ops[rules[i].operator]}: ${f_vals}}`)
			} else {
				//Where rules here
				whereRules.push(`${rules[i].filterName}: {${ops[rules[i].operator] === undefined ? rules[i].operator : ops[rules[i].operator]}: ${f_vals}}`)
			}
		}
		whereFilter  =  whereRules.length  > 0 ? `where: {${whereRules.join(',')}}` : ``;
		havingFilter =  havingRules.length > 0 ? `having: {${havingRules.join(',')}}` : ``;
		queryFilter  = whereRules.length  > 0 ?  whereFilter : ``;
		queryFilter += whereRules.length  > 0 && havingRules.length  > 0 ? `,` : ``;
		queryFilter += havingRules.length > 0 ?  havingFilter : ``;
	} 
	queryFilter = queryFilter === `` ? `relativeDateRange: ${days}` : `filter: {${queryFilter}, relativeDateRange: ${days}}`;
	return queryFilter;
}

// This function returns a full set of counts for the segment as defined by the rules - via GraphQL query.
function getPopulation(rules, days, isTotal=false) {
	const queryFields =  isTotal ? `{uids, pageviews,impressions, visits}`:`{uids, pageviews, impressions, visits, query_id}`;
	const queryFilter = prepQueryFilter(rules, days);
	const query_total = `query GetCounts { ReportCounts(${queryFilter})${queryFields} }`;
	return gql(query_total)
}

/**
 * A schema for attributeValueData
 */
const rawAttributeValueData = {
	rule: null,
	selectedOperator: null,
	selectedValues: null,
	listValuesToDisplay: null,
	attribute: null,
	attributeTyoe: null
}

export default function AddRulePage(props) {
	// Controls the days in 'Time Range' panel
	const [days, setDays] = React.useState(90);

	// Store all rules
	const [rules, setRules] = React.useState([]);

	// Control whether to display the 'done' modal or not
	const [modalState, setModalState] = React.useState(0);

	// The segment name on top of the pie chart
	const [segmentName, setSegmentName] = React.useState("New Segment");

	// The segment's dfp id definded by user
	const [gamId, setGamId] = React.useState("")

	// The segment category chosen by user
	const [categoryName, setCategoryName] = React.useState(SEG_CAT[0]);

	// A description of the current segment
	const [description, setDescription] = React.useState("");

	// The final query send to back-end
	const [segQuery, setSegQuery] = React.useState(TOTAL_POP_QUERY);

	// An object contains information about a specific attribute the exists in rules.
	const [attributeValuesData, setAttributeValuesData] = React.useState({
		...rawAttributeValueData, 
		error: null
	});
	// the population of current rules
	const [uidPopulation, setUidPopulation] = React.useState(0);

	// If countdisplay is still querying the data, then this will be true and 
	//   be passed to time range panel and prohibit user change days within this period.
	const [isCountDisplayLoading, setIsCountDisplayLoading] = React.useState(true);

	// There will be a segementID if this page is navigated from 'Edit Segment' in segment page.
	const segmentID = props.match.params.id;
	if (segmentID !== undefined && editMode < 0) {
		editMode = 0;
	}

	const categories = props.catData.categories;

	// props.data is all the attribute data, it get the value from AppRouter Component.
	Object.keys(props.data).forEach((at) => {
		attTypes.push(at);
		attributes[at] = [];
		Object.keys(props.data[at]).forEach((a) => {
			attributes[at].push(a);
			filterNames[a] = props.data[at][a].field_name.toLowerCase();
			filterTypes[a] = props.data[at][a].filter_type;
			attDataTypes[a] = props.data[at][a].data_type;
		})
	})
	/**
	 * This funcion is passed to time range as a callback.
	 * The 'shouldSendQuery' is serverd for the following use scenerio:
	 * 	step 1. user change the time range first, 
	 *  step 2. play around with rule
	 *  step 3. then hit 'update rule' button,
	 *   In this case, the segment plot should not be updated at stage 1, but this component (AddRulePage)
	 * should be notified that days have been changed. In other cases, like user pressed enter or
	 * clicked on the refresh icon in time range, 'shouldSendQuery' is true thus the countdisplay will
	 * be updated.
	 * @param {*} event 
	 * @param {Integer} d 
	 * @param {Bool} shouldSendQuery
	 */
	const daysChanged = (rules, d, shouldSendQuery=true) => {
		setDays(d);
		if(shouldSendQuery){
			setSegQuery(getPopulation(rules, d));
		}
	}

	/**
	 * This function is called when user de-select a rule from 'rules' panel.
	 */
	const notifyAttributeValues = (rule, attType, att) => {
		try {
			let dims = props.data[attType][att];
			let newAttValData = {
				rule: rule,
				selectedOperator: rule ? rule.operator : dims.operators[0],
				selectedValues: rule ? rule.values : [],
				attribute: att,
				attributeType: attType,
				filterType: dims.filter_type,
				filterName: dims.field_name.toLowerCase(),
				dataType: dims.data_type,
				operators: dims.operators,
				freeInput: dims.field_values.length === 0,
				values: dims.field_values,
				error: null
			};
			setAttributeValuesData(newAttValData)
		} catch(e) {
			setAttributeValuesData({
				...rawAttributeValueData,
				error: e.toString()
			})
		}
		
	}
	/*
	 * Function called when user is done with adding/removing rules
	 */
	const doneClicked = () => {
		setModalState(2);
		population = uidPopulation;
	}
	// function to be passed to AttributeValues, to notify this component for adding new rule
	const notifyAddRule = (newRule) => {
		setModalState(0);
		let rule = {
			...newRule,
			index: prevRuleIndex++
		}
		setRules([...rules, rule]);
		setAttributeValuesData(rawAttributeValueData);

		let newQuery = getPopulation([...rules, rule], days);
		setSegQuery(newQuery);
	}
	/**
	 * Some wrappers. 
	 */
	const segmentNameChanged = event => {
		setSegmentName(event.target.value);
	}
	const gamIdChanged = e => {
		setGamId(e.target.value);
	}
	const categoryNameChanged = val => {
		console.log(val)
		setCategoryName(val)
		// setCategoryName(event.target.value);
	}
	const descriptionChanged = event => {
		setDescription(event.target.value);
	}
	const onCancelClicked = () => {
		setModalState(0);
	}

	/**
	 * This happend while use clicks on the pencil icon on one of the rules.
	 * @param  rule 
	 */
	const removeRule = rule => {
		// Remove the current rule from rules 
		setRules(rules.filter(r => {
			return rule.index !== r.index;
		}));
		// notify the attributeValues component of the rule being removed from rules list
		notifyAttributeValues(rule, rule.attType, rule.attribute);
		// fire the new query to backend to update countDisplay
		setSegQuery(getPopulation(rules.filter(r => {
			return rule.index !== r.index;
		}), days));
	}
	/**
	 * called when user is sure to submit a new segment
	 */
	const onSubmitClicked = () => {
		let mutation;
		if (editMode > 0) {
			mutation = `
				mutation UpdateSegment {
					UpdateSegmentDefinitionById(
						id: "` + segmentID + `",
						name: "` + segmentName + `",
						category: "` + categoryName + `",
						subcategory: "",
						description: "` + description + `",`
						+ prepQueryFilter(rules, days) + `,
						is_active: "Y",
						population: ` + population + `",
						gam_audience_id: "` + gamId + `"
					)
				}
			`;
		} else {
			mutation = `
				mutation CreateSegment {
					CreateSegmentDefinition(
						name: "` + segmentName + `",
						category: "` + categoryName + `",
						subcategory: "",
						description: "` + description + `",`
						+ prepQueryFilter(rules, days) + `,
						population: ` + population + `",
						gam_audience_id: "` + gamId + `"
					)
				}
			`;
		}

		const url = baseUrl;
		const opts = {
			method: "POST",
			headers: { "Content-Type": "application/json" },
			body: JSON.stringify({ query: mutation })
		};
		fetch(url, opts)
			.then(() => {
				window.location.href = "/SegmentsPage";
			})
			.catch(e => {
				console.log("Submit error : " + e);
			})
	}

	/**
	 * require data about a segment only if a segmentID exists in url.
	 */
	const { data: segData, loading: segLoading, error: segError } = useQuery(
		segmentDefinitionsQuery, {skip:segmentID===undefined}
		);
		
	if (segLoading) {
		return(<Loading/>);
	};

	if (segError) {
		return(
			<div style={{marginTop: 350}}>
				<Typography align="center">Error</Typography>
			</div>
		);
	};
	/**
	 * EditMode controls the window after clicking 'done' in Rules panel.
	 */
	if (editMode === 0) {
		editMode = 1;
		const segments = segData.SegmentDefinitions;
		for (let idx in segments) {
			if (segments[idx].id === segmentID) { 
				let segmentRule = JSON.parse(segments[idx].rule);
				let parsedRule = {...segmentRule['filter']['where'], ...segmentRule['filter']['having']};
				let parsedDateRange = segmentRule['filter']['relativeDateRange'];
				for (let subidx in parsedRule) {
					const attributeName = getAttributeFromFilter(subidx, filterNames);
					const attributeType = getAttributeType(attributeName);
					const attributeFilterType = getFilterTypeFromName(attributeName);
					const attributeDataType = getDataTypeFromName(attributeName);
					for (let op in parsedRule[subidx]) {
						let values = [];
						let ruleValues = parsedRule[subidx][op];
						if(attributeName.toLowerCase().includes("krux")) {
							values = ruleValues.map(v => props.data['User']['Krux Segment'].field_values.filter(dv => dv.includes(v))[0])
						} else {
							values = Array.isArray(ruleValues) ? ruleValues : [ruleValues]
						}

						rulesFromList.push({
							index: prevRuleIndex++,
							attType: attributeType,
							attribute: attributeName,
							filterName: subidx,
							filterType: attributeFilterType,
							dataType: attributeDataType,
							operator: op,
							values
						});
					}
				}
				setSegmentName(segments[idx].name);
				setGamId(segments[idx].gam_audience_id);
				setCategoryName(segments[idx].category);
				setDescription(segments[idx].description);
				setRules(rulesFromList);
				setDays(parsedDateRange);
				setSegQuery(getPopulation(rulesFromList, parsedDateRange));
				
				break;
			}
		}
		return (
			<Box m={2}>
				<h1>No such segment</h1>
				<Button href="/" variant="outlined">
					<Home />
					Go to home
				</Button>
			</Box>
		);
	}

	return (
		<Box style={{backgroundColor:"#ffffff", height: "100vh", overflowY: "auto"}}>
			{/**The header component */}
			<ADCHeader editMode={editMode} viewContext={'addrule'}/>
			{/**The main page component */}
			<Grid
				container
				direction="row"
				justify="center"
				alignItems="stretch"
				height="auto"
				style={{padding: "10px", marginTop: "80px"}}
			>
				<Grid item xs={10}>
					<Grid
						container
						direction="row"
						justify="center"
						alignItems="flex-start"
					>
						<Grid item xs={3}>
							<Box justifyContent="flex-start" mr={1}> 
								<DayRangePicker day={days}
								notifyDayChange={(d, shouldSendQuery=true) => daysChanged(rules, d,shouldSendQuery)} isLoading={isCountDisplayLoading}/>
								<AudienceAttributes 
									dimData={props.data}
									notifyAttributeValues={(att, at) => {
										notifyAttributeValues(null, att, at);
									}}/>
							</Box>
						</Grid>
						<Grid item xs={9}>
							<Box display="flex" flexDirection="column" mb={1} mr={1} p={1} style={{background: "#FFFFFF"}} minHeight="120px" border={"1px solid #D3D6D9"}>
								<Box display="flex" flexDirection="row" width="inherit">
									<Typography style={{fontSize:"15px"}}>Rules:</Typography>
								</Box>
								<Box>
									{rules.length === 0 ? (
										<Box m={1}>
											<Typography m={1} p={0}style={{textAlign: "center", color: "#B3B6B9"}}>
												Rules will appear here after being defined in the area below.
											</Typography>
										</Box>
									) : (
										<Box m={1}>
											{rules.map(rule => (
												<Box key={rule.index} m={1} p={0} 
												style={{padding:"3px", 
												borderRadius:"0.2", 
												backgroundColor: "#e0e0eb", 
												display: "inline-block",
												}}>
													<Typography variant="caption" style={{margin: "0"}}>
														<strong>{rule.attribute + " "}</strong>
														{rule.operator}
														<strong>
															{/** Split values by the attr_val_id_split_string for some specific fields like krux-id */}
															{" " + rule.values.map(v => isNaN(v) ? v.split(ATTR_VAL_ID_SPLIT_STRING)[0] : v)}
														</strong>
													</Typography>
													{/** The pencil icon for removeing a specific rule */}
													<IconButton size="small" style={{margin: "0"}} onClick={() => removeRule(rule)}>
														<CancelIcon/>
													</IconButton>
												</Box>
											))}
										</Box>
									)}
									<Grid direction="row" container justify="flex-end" alignContent="flex-end">
										<Button
										style={{width: "100px"}}
										color="primary" 
										disabled={rules.length === 0} 
										onClick={doneClicked}>
											<small>Done</small>
										</Button>
									</Grid>
								</Box>
							</Box>
							<AttributeValues
							{...attributeValuesData}
							dimData={props.data}
							notifyData={attributeValuesData} editMode={editMode} notifyAddRule={notifyAddRule}/>
						</Grid>
					</Grid>
				</Grid>
				<Grid item xs={2}>
					<Box style={{
						borderStyle: 'solid', 
						borderWidth: 1, 
						borderColor: 'lightgray',
						backgroundColor: "#ffffff"
						}}>
					 <CountDisplay 
						 segPopQuery={segQuery}
						 segName={segmentName}
						 description={description}
						 setParentPopulation={setUidPopulation}
						 setParentLoadingState={setIsCountDisplayLoading}/> 
					</Box>
				</Grid>
			</Grid>
			{/**The window for confirming add a new segment */}
			<Modal
				open={modalState === 2}
			>
				<Box style={{borderStyle: 'solid', borderWidth: 0.5, borderColor: 'lightgray', borderRadius: 10, width: "600px", position: "absolute", left: "50%", top: "50%", marginLeft: "-300px", marginTop: "-350px", background: 'white'}}>
					<Box m={3}>
						<Grid
							container
							direction="column"
							spacing={2}
						>
							<Grid item>
								<Box style={{maxWidth: "500px"}} m="auto">
									<Grid
										container
										direction="column"
										justify="flex-start"
										alignItems="flex-start"
										spacing={3}
									>
										<Grid item>
											<Typography variant="h6">SEGMENT DETAILS</Typography>
										</Grid>
										<Grid item style={{width: "100%"}}>
											<Typography>Name segment</Typography>
											<Input
												fullWidth
												value={segmentName}
												onChange={segmentNameChanged}
											/>
										</Grid>
										<Grid item style={{width: "100%"}}>
											<Typography>DFP Id</Typography>
											<Input fullWidth
											value={gamId}
											onChange={gamIdChanged}/>
										</Grid>
										<Grid item style={{width: "100%"}}>
											<Typography style={{marginBottom: "8px"}}>Category name</Typography>
											{/* <TextField
												select
												value={categoryName}
												onChange={categoryNameChanged}
												style={{width: "200px"}}
											>
												{SEG_CAT.map(cat => (
													<MenuItem key={cat} value={cat}>
														<Typography>{cat}</Typography>
													</MenuItem>
												))}
											</TextField> */}
											<Autocomplete
											id="modal-category-id"
											options={SEG_CAT}
											value={categoryName}
											getOptionLabel={option=>option}
											style={{width:300}}
											onChange={(event, newValue) => {
												categoryNameChanged(newValue)}}
											renderInput={params => (
												<TextField {...params} label="Category Name" variant="outlined" fullWidth
												/>
											)}>

											</Autocomplete>
										</Grid>
										<Grid item style={{width: "100%"}}>
											<Typography>Description</Typography>
											<TextField
												fullWidth
												multiline
												variant="outlined"
												value={description}
												onChange={descriptionChanged}
												rows={5}
											/>
										</Grid>
										<Grid item style={{width: "480px"}}>
											<Typography>RULES</Typography>
											{rules.map(rule => (
												<Box key={rule.index} m={1} p={0} style={{backgroundColor: "#bbb", display: "inline-block"}}>
													<Typography variant="caption" style={{margin: "0"}}>
														<strong>{rule.attribute + " "}</strong>
														{rule.operator}
														<strong>{" " + rule.values}</strong>
													</Typography>
												</Box>
											))}

										</Grid>
										<Grid item style={{width: "100%", marginTop: "20px"}}>
											<Grid
												container
												direction="row"
												justify="flex-end"
												alignContent="flex-end"
												spacing={2}
											>
												<Grid item>
													<Button
														variant="outlined"
														onClick={onCancelClicked}
														style={{width: "120px"}}
													>
														Cancel
													</Button>
												</Grid>
												<Grid item>
													<Button
														variant="contained"
														color="primary"
														style={{width: "120px"}}
														onClick={onSubmitClicked}
													>
														Submit
													</Button>
												</Grid>
											</Grid>
										</Grid>
									</Grid>
								</Box>
							</Grid>
						</Grid>
					</Box>
				</Box>
			</Modal>
		</Box>
	);
}