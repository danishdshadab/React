import React from 'react';
import {
	Grid,
	Button,
    Typography,
    Box,
    AppBar
} from '@material-ui/core';

// import ExitToAppIcon from '@material-ui/icons/ExitToApp';
import GroupAddIcon from '@material-ui/icons/GroupAdd';
import ListIcon from '@material-ui/icons/List';

/**
 * The header on all pages
 * it controls what icons to be displayed by props.viewContext
 */
export default function ADCHeader(props) {
    return(
        <AppBar sticky="true">
        <Box>
        <Grid
            container
            direction="row"
            justify="space-between"
            alignItems="flex-start"
            style={{backgroundColor: "#dadfeb", height: "75px"}}
        >
            <Grid item>
                <Grid
                    container
                    direction="column"
                    justify="space-between"
                    alignItems="flex-start"
                    style={{height: "75px"}}
                >
                    <Grid item style={{backgroundColor:"#5b7bd4", height: "75px"}}>
                            <Typography variant="h1" 
                            style={{fontFamily:"Helvetica Neue", color:"#FFFFFF", fontSize: '20px', padding: '6px'}}>
                            <strong>Audiance</strong><br/>
                                <strong>Data</strong><br/>
                                <strong>Cloud</strong>
                            </Typography>
                    </Grid>
                    <Grid item>
                        {/** Hard coded logic for determing what icons need to be shown on the header. */}
                    {props.viewContext === 'addrule' ? (
                        <Button
                        style={{height: "75px", width: "75px", padding: "1px", borderRadius:"0"}}
                         href="/SegmentsPage">
                            <Grid container direction="column" justify="center" alignItems="center">
                                <ListIcon  style={{color:"#E63946"}} fontSize="large"/>
                                <Typography style={{color:"#55585c", fontSize: '9px'}}>Segments</Typography>
                            </Grid>
                        </Button>
                    ) : (
                        <Button style={{height: "75px", width: "75px", padding: "1px", borderRadius:"0"}} href="/">
                            <Grid container direction="column" justify="center" alignItems="center">
                                <GroupAddIcon  style={{color:"#E63946"}} fontSize="large"/>
                                <Typography  variant="body1" style={{color:"#55585c", fontSize: '9px'}}>New Segment</Typography>
                            </Grid>
                        </Button>
                    )}
                    {props.editMode > 0 ? (
                        <Button style={{height: "75px", width: "75px", padding: "1px", borderRadius:"0"}} href="/">
                            <Grid container direction="column" justify="center" alignItems="center">
                                <GroupAddIcon  style={{color:"#E63946"}} fontSize="large"/>
                                <Typography variant="body1" style={{color:"#55585c", fontSize: '9px'}}>New Segment</Typography>
                            </Grid>
                        </Button>
                    ) : (null)}
                    </Grid>
                </Grid>
            </Grid>
            {/* 
            This was supposed to be a button to handle login/exit, however it's not implemented.
            <Grid item>
                <Button>
                    <ExitToAppIcon  style={{color:"#E63946"}}/>
                </Button>
            </Grid> */}
        </Grid>
        </Box>
        </AppBar>
    )
}