import React from "react";
import {
  Grid,
  Box,
  Typography,
  List,
  MenuItem,
  Input,
  TextField,
  InputAdornment,
  Button,
  Collapse,
  ButtonGroup,
  Tooltip,
  Fade,
  Snackbar
} from "@material-ui/core";
import {
  Search,
  AddCircle,
  RemoveCircle,
  Add,
  Visibility,
  VisibilityOff,
  Done
} from "@material-ui/icons";
import CheckBoxOutlineBlankIcon from '@material-ui/icons/CheckBoxOutlineBlank';
import CheckBoxIcon from '@material-ui/icons/CheckBox';
import { FixedSizeList } from "react-window";
import {default as AttrValuesListItem} from "./AttrValuesListItem";
import {ATTR_VAL_ID_SPLIT_STRING} from "./../constants";

export default class AttributeValues extends React.Component {
  /**
   * props:
   *  Object notifyData
   * @param {*} props
   */
  constructor(props) {
    super(props);
    this.state = {
      selectedOperator: props.selectedOperator,
      // This is always an array
      selectedValues: props.selectedValues || [],
      listValuesToDisplay: props.values || [],
      showRuleString: false,
      searchText: "",
      searchInputTimeout: null,
      ruleString: "",
      snackBarOpen: false,
      snackBarMessage: "",
      snackBarCloseTimeout: null
    };
  }
  /**
   * function for adding a value
   */
  valuePlusClicked = val => {
    if (
      this.state.selectedOperator !== "EQ" ||
      this.state.selectedValues.length === 0
    ) {
      if (this.state.selectedValues.indexOf(val) === -1) {
        this.setState({ selectedValues: [...this.state.selectedValues, val] });
      }
    } else {
      clearTimeout(this.state.snackBarCloseTimeout);
      this.setState({
        snackBarOpen: true,
        snackBarMessage:
          "EQ operator only allows one selected values, please remove the current one first!",
        snackBarCloseTimeout: setTimeout(
          () => this.setState({ snackBarOpen: false }),
          5000
        )
      });
    }
  };

  handleSelectAllClick = (vals) => {
    if(this.state.selectedValues.length !== 0){
      this.setState({selectedValues: []})
    } else {
      this.setState({selectedValues: vals})
    }
  }

  /**
   * function for removing a value
   */
  valueMinusClicked = val => {
    this.setState({
      selectedValues: this.state.selectedValues.filter(v => val !== v)
    });
  };

  /**
   * Set the filter as defined by search
   */
  setFilteredValuesToDisplay = word => {
    this.setState({
      listValuesToDisplay: this.props.values.filter(
        v => v.toLowerCase().indexOf(word.toLowerCase()) !== -1
      )
    });
  };

  /**
   * To show or not show the rule string
   */
  // toggleRuleString = () => {
  //   this.setState({
  //     showRuleString: !this.state.showRuleString
  //   });
  // };

  /**
   * function for tracking the search input
   */
  searchOnChange = val => {
    if (this.state.listValuesToDisplay.length < 100) {
      this.setState({
        searchText: val
      });
    } else {
      // We don't want the filter actiong to be called on a huge list everytime use make changes
      clearTimeout(this.state.searchInputTimeout);
      this.setState({
        searchInputTimeout: setTimeout(
          () => this.setState({ searchText: val }),
          400
        )
      });
    }
  };
  /**
   * Function called when 'update' or 'add rule' is clicked, generates a json with fields that a rule
   *  will need in AddRulePage
   */
  finalBtnCLicked = () => {
    let newRule = {
      attType: this.props.attributeType,
      attribute: this.props.attribute,
      filterName: this.props.filterName,
      filterType: this.props.filterType,
      dataType: this.props.dataType,
      operator: this.state.selectedOperator,
      values: this.state.selectedValues
    };
    this.props.notifyAddRule(newRule);
  };

  /**
   * Update State according to props change
   */
  static getDerivedStateFromProps(props, state) {
    if (
      props.rule !== state.prevPropsRule ||
      props.attributeType !== state.prevPropsAttributeType ||
      props.attribute !== state.prevPropsAttribute
    ) {
      return {
        prevPropsRule: props.rule,
        prevPropsAttributeType: props.attributeType,
        prevPropsAttribute: props.attribute,
        selectedOperator: props.selectedOperator,
        selectedValues: props.selectedValues
      };
    }
    return null;
  }

  render() {
    const filteredValues = this.props.values
      ? this.props.values
          .filter(v =>
            v.toLowerCase().includes(this.state.searchText.toLowerCase())
          )
          .sort()
      : [];

    /**
     *  Function to be passed to FixedSizeList for rendering rows 
     */
    const filteredRow = ({ index, style }) => {
      return (
        <div style={style}>
          <AttrValuesListItem itemKey={index} 
          onClick={() => this.valuePlusClicked(filteredValues[index])}
          icon={<AddCircle/>} 
          itemText={filteredValues[index].split(ATTR_VAL_ID_SPLIT_STRING)[0]}/>
        </div>
      );
    };

    const handleSelectAllClickWraper = () => {
      this.handleSelectAllClick(filteredValues)
    }

    return this.props.attribute === null ||
      this.props.attributeType === null ? (
      <Box
        justifyContent="flex-start"
        height={"65vh"}
        mr={1}
        p={1}
        style={{ background: "#FFFFFF" }}
        border={"1px solid #D3D6D9"}
      >
        <Typography style={{ fontSize: "14px" }}>Attribute Values:</Typography>
        {this.props.error ? (
          <Tooltip
            TransitionComponent={Fade}
            TransitionProps={{ timeout: 600 }}
            title="This can be caused by the attribute has been removed. Try building this rule again from Audience Attributes"
          >
            <Box borderLeft={3} marginTop={3} borderColor={"#eb4664"}>
              <Typography
                style={{
                  margionTop: "10px",
                  marginBottom: "0px",
                  marginLeft: "0px",
                  fontSize: "13px",
                  padding: "2px"
                }}
                width={"45vh"}
              >
                <strong>An error occured: </strong>
                {this.props.error}
              </Typography>
            </Box>
          </Tooltip>
        ) : (
          <Box style={{ padding: "40px", paddingTop: "170px" }}>
            <Typography style={{ textAlign: "center", color: "#B3B6B9" }}>
              Select a time frame and data attribute from the left to begin
            </Typography>
          </Box>
        )}
      </Box>
    ) : (
      <Box
        justifyContent="flex-start"
        mr={1}
        p={1}
        style={{ background: "#FFFFFF", height: "auto" }}
        border={"1px solid #D3D6D9"}
      >
        <Typography style={{ fontSize: "14px" }}>Attribute Values:</Typography>
        {/* <Collapse in={this.state.showRuleString} timeout={"auto"}>
          <Box borderLeft={3} borderColor={"#325C82"}>
            <Typography
              style={{
                margionTop: "10px",
                marginBottom: "0",
                marginLeft: "10px",
                fontSize: "12px"
              }}
              width={"45vh"}
            >
              <strong>{this.props.filterName}</strong>
              {" " + this.state.selectedOperator + " "}
              <strong>{this.state.selectedValues.map(v => isNaN(v) ? v.split(ATTR_VAL_ID_SPLIT_STRING)[0] : v).join(", ")}</strong>
            </Typography>
          </Box>
        </Collapse> */}
        <Box>
          <Box p={1} m={1}>
            <Grid container direction="column" spacing={1}>
              <Grid item xs>
                <Typography>{this.props.attribute}</Typography>
              </Grid>
              <Grid item>
                <Grid
                  container
                  direction="row"
                  justify="flex-start"
                  alignItems="flex-end"
                  spacing={1}
                >
                  <Grid item>
                    {/**The dropdown component for selecting operators */}
                    <TextField
                      select
                      value={this.state.selectedOperator}
                      onChange={event =>
                        this.setState({selectedOperator: event.target.value})
                      }
                    >
                      {this.props.operators.map(op => (
                        <MenuItem key={op} value={op}>
                          <Typography>{op}</Typography>
                        </MenuItem>
                      ))}
                    </TextField>
                  </Grid>
                  {/** if this is not a free input attribute, then
                  provide user a search input for finding values they want
                   */}
                  <Grid item>
                    {this.props.freeInput ? (
                      ""
                    ) : (
                      <Input
                        value={this.state.searchText}
                        onChange={event =>
                          this.searchOnChange(event.target.value)
                        }
                        placeholder="Search values..."
                        endAdornment={
                          <InputAdornment position="end">
                            <Search />
                          </InputAdornment>
                        }
                      />
                    )}
                  </Grid>
                </Grid>
                {this.props.freeInput ? (
                  <Grid container direction="row" justify="center" width="100%">
                    <Box style={{ width: "100%", height: "100%" }}>
                      <TextField
                        fullWidth
                        multiline
                        variant="outlined"
                        placeholder="Enter your comma separated list of values here ..."
                        value={this.state.selectedValues.join(",")}
                        onChange={event =>
                          this.setState({
                            selectedValues: event.target.value.split(",")
                          })
                        }
                        rows="12"
                      />
                    </Box>
                  </Grid>
                ) : (
                   /**If it's not, provide list component to select from. */
                  <Grid
                    container
                    direction="row"
                    justify="center"
                    width="100%"
                    spacing={1}
                  >
                    <Grid item xs={6}>
                      <Box whiteSpace="nowrap" padding="10px">
                        <FixedSizeList
                          height={500}
                          width={"100%"}
                          itemSize={50}
                          itemCount={filteredValues.length}
                        >
                          {filteredRow}
                        </FixedSizeList>
                      </Box>
                    </Grid>
                    <Grid item xs={6}>
                      <Box style={{ overflow: "auto" }} padding="10px">
                        <List component="nav" style={{ maxHeight: "50vh" }}>
                          {this.state.selectedValues.map(val => (
                            <AttrValuesListItem key={val}
                            icon={<RemoveCircle/>}
                            onClick={() => this.valueMinusClicked(val)}
                            itemText={val.split(ATTR_VAL_ID_SPLIT_STRING)[0]}/>
                          ))}
                        </List>
                      </Box>
                    </Grid>
                  </Grid>
                )}
              </Grid>
            </Grid>
          </Box>
        </Box>
        {/**The rule inspecting part */}
        <Box justifyContent="flex-start" m={1}>
          <Grid
            container
            direction="row"
            justify="flex-end"
            alignContent="flex-end"
          >
            <Grid item>
              <Box m={1}>
                <ButtonGroup
                  size="small"
                  aria-label="small contained button group"
                >
                  { this.props.freeInput || this.state.selectedOperator === "EQ" ? null :
                      <Button onClick={() => handleSelectAllClickWraper()}>
                        {this.state.selectedValues.length === 0 ? <CheckBoxOutlineBlankIcon/> : <CheckBoxIcon/>}
                        {this.state.selectedValues.length === 0 ? "Select All" : "Unselect All"}
                      </Button>
                  }

                  <Button
                    disabled={
                      this.state.selectedOperator === "" ||
                      this.state.selectedValues.length === 0 ||
                      this.state.selectedOperator === null
                    }
                    onClick={this.finalBtnCLicked}
                  >
                    {this.props.rule ? <Done /> : <Add />}
                    {this.props.rule ? "Update" : "Add Rule"}
                  </Button>
                </ButtonGroup>
              </Box>
            </Grid>
          </Grid>
        </Box>
        <Snackbar
          TransitionComponent={Fade}
          open={this.state.snackBarOpen}
          anchorOrigin={{ vertical: "bottom", horizontal: "left" }}
          key="error-snack-bar"
        >
          <Box
            boxShadow={3}
            bgcolor="#ffffff"
            borderRadius="1%"
            p={1}
            width="300px"
          >
            <Typography style={{ fontSize: "12px", color: "#f28061" }}>
              {this.state.snackBarMessage}
            </Typography>
          </Box>
        </Snackbar>
      </Box>
    );
  }
}
