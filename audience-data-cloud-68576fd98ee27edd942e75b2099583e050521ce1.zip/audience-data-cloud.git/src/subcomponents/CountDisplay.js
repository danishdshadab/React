import React from 'react';
import {
	PieChart,
	Pie,
	Cell,
	ResponsiveContainer
} from 'recharts';
import {
	Grid,
	Box,
	Typography,
	CircularProgress
} from '@material-ui/core';
import { useQuery } from '@apollo/react-hooks';
import {TOTAL_POP_QUERY} from './../constants';

export default function CountDisplay(props){
	// This component ingests segPopQuery and make query only if the query changes.
	const [segPopQuery, setSegPopQuery] = React.useState(props.segPopQuery);
	//Fetch the segment count
	const { data: SegPopData, loading: SegPopLoading, error: SegPopError } = useQuery(segPopQuery);	
	//Fetch the total count, this part should be static and won't be changed after first time fetching
	const { data: PopData, loading: PopLoading, error: PopError } = useQuery(TOTAL_POP_QUERY);
	
	if(segPopQuery.definitions !== props.segPopQuery.definitions){
		setSegPopQuery(props.segPopQuery);
	}

	if(SegPopLoading || PopLoading){
		props.setParentLoadingState(true);
		return (
			<Box m={1} height={200}>
				<div style={{margin: "auto", height: 40, width: 40, marginTop: 300, marginBottom: 16}}>
					<CircularProgress style={{margin: "auto"}} />
				</div>
				<Typography align="center">Loading ...</Typography>
			</Box>
		)
	}
	props.setParentPopulation(SegPopData ? SegPopData.ReportCounts.uids : 0);
	props.setParentLoadingState(false);
	return(
		<Box marginRight="5px" height="80%">
		{((SegPopError || PopError) ? 
			<Box style={{marginTop: 350, justifyContent: "center"}}>
				<Typography align="center">Error</Typography>
			</Box>
			:
			(<Box m={1}>
				<Typography variant="h5" align="center"><b>{props.segName}</b></Typography> <br />
				<Typography variant="body2">{props.description}</Typography>
				
				<ResponsiveContainer  width="100%" height={200}>
					<PieChart>
						<Pie
							data={[
								{value: SegPopData.ReportCounts.uids},
								{value: PopData.ReportCounts.uids - SegPopData.ReportCounts.uids}
							]}
							dataKey="value"
							animationBegin={0}
							innerRadius="70%"
							outerRadius="100%"
						>
							<Cell fill="#003466"></Cell>
							<Cell fill="#325C82"></Cell>
						</Pie>
						<Pie
							data={[
								{value: SegPopData.ReportCounts.visits},
								{value: PopData.ReportCounts.visits - SegPopData.ReportCounts.visits}
							]}
							dataKey="value"
							animationBegin={0}
							innerRadius="30%"
							outerRadius="70%"
						>
							<Cell fill="#3399FE"></Cell>
							<Cell fill="#5CAFFD"></Cell>
						</Pie>
					</PieChart>
				</ResponsiveContainer>
				<Grid container style={{margin: "auto"}}>
					<Grid item xs={6}>
					{SegPopData.ReportCounts === PopData.ReportCounts ? null : (
						<div>
							<Typography variant="body2" style={{fontSize:"13px"}}><b>Segment</b></Typography>
							<div style={{display: "flex"}}>
								<Typography variant="body2" style={{fontSize:"11px"}}>{SegPopData.ReportCounts.uids} Users</Typography>
								<div style={{width: "6px", height: "6px", background: "#003466", margin: "6px"}} />
							</div>
							<div style={{display: "flex"}}>
								<Typography variant="body2" style={{fontSize:"11px"}}>{SegPopData.ReportCounts.visits} Visits</Typography><br/>
								<div style={{width: "6px", height: "6px", background: "#3399FE", margin: "6px"}} />
							</div>
							<Typography variant="body2" style={{fontSize:"11px"}}>{(SegPopData.ReportCounts.visits / SegPopData.ReportCounts.uids).toFixed(2)} V/U</Typography>
						</div>
					)}
					</Grid>
					<Grid item xs={6}>
						<Typography variant="body2" style={{fontSize:"13px"}}><b>Population</b></Typography>
						<Typography variant="body2" style={{fontSize:"11px"}}>{PopData.ReportCounts.uids} Users</Typography>
						<Typography variant="body2" style={{fontSize:"11px"}}>{PopData.ReportCounts.visits} Visits</Typography>
						<Typography variant="body2" style={{fontSize:"11px"}}>{(PopData.ReportCounts.visits / PopData.ReportCounts.uids).toFixed(2)} V/U</Typography>
					</Grid>
				</Grid>
				
				<ResponsiveContainer  width="100%" height={200}>
					<PieChart>
						<Pie
							data={[
								{value: SegPopData.ReportCounts.impressions},
								{value: PopData.ReportCounts.impressions - SegPopData.ReportCounts.impressions}
							]}
							dataKey="value"
							animationBegin={0}
							innerRadius="70%"
							outerRadius="100%"
						>
							<Cell fill="#003466"></Cell>
							<Cell fill="#325C82"></Cell>
						</Pie>
						<Pie
							data={[
								{value: SegPopData.ReportCounts.pageviews},
								{value: PopData.ReportCounts.pageviews - SegPopData.ReportCounts.pageviews}
							]}
							dataKey="value"
							animationBegin={0}
							innerRadius="30%"
							outerRadius="70%"
						>
							<Cell fill="#3399FE"></Cell>
							<Cell fill="#5CAFFD"></Cell>
						</Pie>
					</PieChart>
				</ResponsiveContainer>
				<Grid container style={{margin: "auto"}}>
					<Grid item xs={6}>
					{SegPopData.ReportCounts === PopData.ReportCounts? "" : (
						<Box>
							<Typography variant="body2" style={{fontSize:"13px"}}><b>Segment</b></Typography>
							<Box style={{display: "flex"}}>
								<Typography variant="body2" style={{fontSize:"11px"}}>{SegPopData.ReportCounts.impressions} Imps.</Typography>
								<div style={{width: "6px", height: "6px", background: "#003466", margin: "6px"}} />
							</Box>
							<Box style={{display: "flex"}}>
								<Typography variant="body2" style={{fontSize:"11px"}}>{SegPopData.ReportCounts.pageviews} PgVws.</Typography>
								<div style={{width: "6px", height: "6px", background: "#3399FE", margin: "6px"}} />
							</Box>
							<Typography variant="body2" style={{fontSize:"11px"}}>{(SegPopData.ReportCounts.impressions / SegPopData.ReportCounts.pageviews).toFixed(2)} I/PV</Typography>
						</Box>
					)}
					</Grid>
					<Grid item xs={6}>
						<Typography variant="body2" style={{fontSize:"13px"}}><b>Population</b></Typography>
						<Typography variant="body2" style={{fontSize:"11px"}}>{PopData.ReportCounts.impressions} Imps.</Typography>
						<Typography variant="body2" style={{fontSize:"11px"}}>{PopData.ReportCounts.pageviews} PgVws.</Typography>
						<Typography variant="body2" style={{fontSize:"11px"}}>{(PopData.ReportCounts.impressions / PopData.ReportCounts.pageviews).toFixed(2)} I/PV</Typography>
					</Grid>
				</Grid>
			</Box>))
		}
		</Box>
	);
}
