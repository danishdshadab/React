import React from 'react';
import {
	Box,
	Typography,
	List,
	ListItem,
	ListItemText,
    Collapse
} from '@material-ui/core'
import {
	ExpandMore,
	ExpandLess,
} from '@material-ui/icons';

export default function AudienceAttributes(props){
    const dimJson = props.dimData;

    let cleanedDimData = dimJson;
    let attTypes = [];
    let attributes = {};
    let filterNames = {};
    let filterTypes = {};
    let attDataTypes = {};
    for (let at in cleanedDimData) {
        attTypes.push(at);
        attributes[at] = [];
        for (let a in cleanedDimData[at]) {
            attributes[at].push(a);
            filterNames[a] = cleanedDimData[at][a].field_name;
            filterTypes[a] = cleanedDimData[at][a].filter_type;
            attDataTypes[a] = cleanedDimData[at][a].data_type;
        }
    }
    /**
     * props:
     *   object<Map> attributes;
     *   function attributItemClicked(att);
     *   obejct<Map> attTypes 
     */
    const [selectedAttType, setSelectedAttType] = React.useState("");
    const [selectedAttribute, setSelectedAttribute] = React.useState("");
  //  const [menuJson, setMenuJson] = React.useState({});
    /**
     * creates expandible list based on given attType dynamically.
     * This is called while rendering
     */
    const spawnAttList = (attType) => {
        let subAttributes = attributes[attType];
        subAttributes = subAttributes.sort();
        return (
            <Box key={attType}>
                <ListItem button 
                    onClick={() => {
                        let setText = attType === selectedAttType ? "" : attType; 
                        setSelectedAttType(setText)
                    }}  
                    style={{width: "100%", background: "#FFFFFF", borderTop: "1px solid #465775"}}>
                    <ListItemText primary={attType} />
                    {selectedAttType === attType ? <ExpandLess /> : <ExpandMore />}
                </ListItem>
                <Collapse 
                    in={selectedAttType === attType} 
                    timeout="auto">
                    <List style={{width: "100%"}}>
                        {subAttributes.map(att => (
                            <ListItem
                                key={att}
                                button
                                style={{fontSize: "12px"}}
                                selected = {selectedAttribute === att}
                                onClick = {() => {
                                    setSelectedAttribute(att);
                                    generateSelectedAttributeValues(attType, att); }}
                            >
                                {att}
                            </ListItem>
                        ))}
                    </List>
                </Collapse>
            </Box>
        )
    }
    /**
     * Notify parent component (the AddRulePage) that user has selected an attribute.
     */
    const generateSelectedAttributeValues = (attType, att) => {
        props.notifyAttributeValues(attType, att)
    }


    return(
        <Box justifyContent="flex-start"  bgcolor={"#FFFFFF"} p={1} border={"1px solid #D3D6D9"} height="100%">
            <Typography style={{fontSize:"14px"}}>Audience Attributes:</Typography>
                <List style={{maxHeight: "70vh", overflow: "auto"}}>
                    {attTypes.map(spawnAttList)}
                </List>
        </Box>
    )
}