import {
	Box,
	Typography,
	CircularProgress
} from '@material-ui/core';

import React from 'react';


/**
 * A static component for all loading animations
 */
export default function Loading(){
    return (<Box m={1} height={200}>
				<div style={{margin: "auto", height: 40, width: 40, marginTop: 300, marginBottom: 16}}>
					<CircularProgress style={{margin: "auto"}} />
				</div>
				<Typography align="center">Loading ...</Typography>
			</Box>)
}