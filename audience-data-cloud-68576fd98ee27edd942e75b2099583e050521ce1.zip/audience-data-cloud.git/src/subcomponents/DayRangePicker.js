import React from 'react';
import {
	Grid,
	Box,
	Typography,
	TextField,
	IconButton
} from '@material-ui/core';
import {
	Autorenew
} from '@material-ui/icons';
import ClearIcon from '@material-ui/icons/Clear';
import {makeStyles} from '@material-ui/core/styles';

const btnStyle = makeStyles(theme => ({
	dayBtn : {
		color: "#2983c4"
    },
    cancelBtn: {
        color: "#ff5050"
    }
}))

/**
 * Below is the functional component for the date picker on top left corner of the 
 * tool.
 * @param {*} props 
 */
export default function DayRangePicker(props) {

    // props.day === -1 for testing purpose, as one day data is faster to load
    const [dayDisplay, setDayDisplay] = React.useState(props.day === -1 ? 1 : props.day);

    // This field indicates whether user has correct input for the days
    const [textError, setTextError] = React.useState(false);

    // Used by addBuffer as a buffer field
    const [dayChangeBuffer, setDayChangeBuffer] = React.useState(null);

    const classes = btnStyle()

    const dayDisplayValidation = (newDay) => {
        setDayDisplay(newDay);
        let notValid = newDay < 1 || newDay > 90; 
        setTextError(notValid);
        if(!notValid){
            addBuffer(newDay);
        }
    }

    /**
     * Goal:
     *  wait for half second of no action from user, then pass the new day range to parent components.
     * Reason for waiting half second:
     *  Frequently update parent component data field will cause the application slow to react.
     * How:
     *  setTimeout(() => {
            props.notifyDayChange(newDay, false);
        } ,500)
        props.notifyDayChange(...) will not be called until 500 ms of nochange passed.
        If this function receive new values, clearTimeOut(...) will kill the previous setTimeout(...).
        And assign dayChangeBuffer a new Timeout.
     * @param {Integer} newDay 
     */
    const addBuffer = (newDay) => {
        clearTimeout(dayChangeBuffer)
        setDayChangeBuffer(setTimeout(() => {
            props.notifyDayChange(newDay, false);
        } ,500))
    }

    /**
     * A wrapper for notifying the parent component for any change on time range.
     */
    const notifyDayChange = () => {
        props.notifyDayChange(dayDisplay);
    }

    return(
    <Box mb={1} p={1} bgcolor={"#FFFFFF"} height={"120px"} border={"1px solid #D3D6D9"}>
        <Grid container direction="row" style={{marginBottom: "10px"}} alignItems="flex-start">
            <Grid item xs={10}>
                <Typography style={{fontSize:"14px"}}>Time Range (days):</Typography>
            </Grid>
            <Grid item xs={2}>
                <IconButton 
                variant="outlined"
                disabled={textError || props.isLoading}
                className={classes.dayBtn}
                onClick={notifyDayChange}>
                    <Autorenew fontSize="small"/>
                </IconButton>
            </Grid>
        </Grid>
        <Grid container direction="row" justify="center" alignContent="center">
            <TextField
            onKeyDown={(e) => {
                if(e.keyCode === 13 && !textError) {
                    notifyDayChange(dayDisplay)
                }
            }}
            value={dayDisplay}
            disabled={props.isLoading}
            error={textError}
            style={{backgroundColor: "#ffffff", width: "80%"}} 
            onChange={(e) => dayDisplayValidation(e.target.value)}
            id="day-range-selector" 
            label="1 ~ 90" type="number"/>
        </Grid>
    </Box>
    )
}