import React from "react";
import {
  ListItem,
  ListItemText,
  IconButton,
} from "@material-ui/core";

/**
 * The functional component for each value available for 
 * @param {Object} props 
 */
export default function AttrValuesListItem(props){
    return (
        <ListItem key={props.itemKey} style={{paddingLeft: "0px"}}>
            <IconButton onClick={() => props.onClick()}>
                {props.icon}
            </IconButton>
            <ListItemText primary={props.itemText}/>
        </ListItem>
    )
}