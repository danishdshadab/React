// This function accepts a (proper) filter name and returns the corresponding menu item name
// ex. visit_referrer --> Visit Referrer
export const getAttributeFromFilter = (fil, filterNames) => {
    for (let a in filterNames) {
        if (filterNames[a] === fil) {
            return a;
        }
    }
    return fil;
}