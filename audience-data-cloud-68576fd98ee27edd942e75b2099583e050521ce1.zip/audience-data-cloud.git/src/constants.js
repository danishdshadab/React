/**
 * Define global constants here
 */
import gql from 'graphql-tag';

export const baseUrl = "https://adc.globeandmail.com:443/graphql";

// If you want to hide an attribute's name from its id, use this as separater in snowflake
export const ATTR_VAL_ID_SPLIT_STRING = "|||||";
export const KRUX_SEGMENT_FIELD_NAME = "audiencesegmentids";
export const SEG_CAT = [
    "Business","Lifestyle","Education","Travel","Prizm","Food & Drink","Government","Finance","Newsletter","Home & Garden","Auto","Legal","Real Estate",
    "Style & Fashion","Income","News","Gender_Age","Entertainment","Traffic Source","Gender","International","Marketing","Funeral Home","Health","Charity",
    "Science","Ethnicity","Company Size","Marital Status","Income_Age","Special Report","Technology","User","Environment","Careers","Sports","Age","Energy",
    "Podcast","USA","Age_HHI","Gender_HHI","Interest","Language","Shopping","Arts","Test","Opinion","Family","Retail","Politics","Company Revenue"
];
export const TOTAL_POP_QUERY = gql(`
	query GetCounts {
		ReportCounts(
			relativeDateRange: 90
		){
			uids 
			pageviews 
			impressions 
			visits
		}
	}
`);