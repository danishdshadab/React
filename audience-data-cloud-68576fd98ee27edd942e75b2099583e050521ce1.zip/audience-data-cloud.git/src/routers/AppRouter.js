import React from 'react';
import { BrowserRouter, Route, Switch } from 'react-router-dom';
import {useQuery} from '@apollo/react-hooks';
import AddRulePage from '../components/AddRulePage';
import SegmentsPage from '../components/SegmentsPage';
import NotFoundPage from '../components/NotFoundPage';
import gql from 'graphql-tag';

import {Loading} from "./../subcomponents";

const AppRouter = () => {

	const ADCDimensionsQuery = gql(`
		{
			Dimension {
				table_name
				field_name
				field_values
				operators
				data_type
				filter_type
				attribute_type
				attribute_name
			}
		}
    `)
    
    const CategoryQuery = gql(`{
        Categories
    }`)

    const { data: dimData, loading: dimLoading, error: dimError } = useQuery(ADCDimensionsQuery);
    const { data: catData, loading: catLoading, error: catError } = useQuery(CategoryQuery);
	if(dimLoading || catLoading){
		return (
			<Loading/>
		)
	}

    //This function parses the data returned from the database into a JSON object suitable to driving the menu for the appliction.
    const generateMenuJSON = (data) => {
        // console.log('Generating Menu JSON ... ')
        // Object that contains the menu/dimension data - driven/generated from the DB
        let dimData = {
            "User": {},
            "Web Interaction": {},
            "Digital Advertising": {}
        };
        if(data !== undefined) {
            let fValue  = [];
            data.Dimension.forEach(dim => {
                if (dim.field_values === null) {
                    fValue = [];
                } else if(dim.data_type === 'integer'){
                    fValue = dim.field_values
                } else if(dim.field_values[0] === "\""){
                    fValue = dim.field_values.substring(1, dim.field_values.length - 1).split('","');
                } else {
                    fValue = dim.field_values.split(",")
                }

                let attMeta = {
                    'field_name': dim.field_name,
                    'field_values': fValue,
                    'operators': dim.operators === null ? [] : dim.operators.replace(/"/g, "",'').split(','),
                    'filter_type': dim.filter_type,
                    'data_type': dim.data_type
                }
                let attType = dim.attribute_type;
                dimData[attType][dim.attribute_name] = attMeta
            })
            return(dimData);
        }
	}

	const dimJSON = generateMenuJSON(dimData);

	return(
        <BrowserRouter>
        {
            dimError ?
            <div>An Error Occured: {dimError.toString()}</div>
            :
            <div>
                <Switch>
                    <Route path="/" 
                        component={(props) => <AddRulePage {...props} data={dimJSON} catData={catData}/>} exact={true}/>
                    <Route path="/edit/:id" 
                        component={(props) => <AddRulePage {...props} data={dimJSON} catData={catData}/>} />
                    <Route path="/SegmentsPage" 
                        component={(props) => <SegmentsPage {...props} data={dimJSON} catData={catData}/>} />
                    <Route component={NotFoundPage} />
                </Switch>
            </div>
        }
        </BrowserRouter>
)};
export default AppRouter;
