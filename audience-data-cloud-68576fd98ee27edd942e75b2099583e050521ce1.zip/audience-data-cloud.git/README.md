## [Audience Data Cloud](https://adc.globeandmail.com) - Query Generator (front-end) 

This documentation is formatted as below:

1. A brief introduction 
   
2. Component structure 
   
3. What's left to be done

### A brief introduction
This project is written using Javascript with [React](https://reactjs.org) framework, with a slightly mix of both [functional component and class components](https://reactjs.org/docs/components-and-props.html#function-and-class-components). We use [material-ui](https://material-ui.com/) for most user interface components, and [apollo graphql](https://github.com/apollographql/apollo-client) for api channel with back-end.

#### Installation
1. ```npm install --save``` to first install all libraries.
2. ```npn run dev``` for starting a local dev version.
3. ```npm run build``` for building the production package. \
   This will produce a `build` directory which contains all file needed to deploy to server, simply `sftp` the build directory to `/home/www` of the server, and restart `nginx` to deploy.

#### Some useful chrome Extensions
   - [React Developer Tools](https://chrome.google.com/webstore/detail/react-developer-tools/fmkadmapgofadopljbjfkapdkoienihi?hl=en) let you inspect components with the name you defined in js, and it has real-time hook with component states.
   - [CORS Chrome Extension](https://chrome.google.com/webstore/detail/allow-cors-access-control/lhobafahddgcelffkeicbaginigeejlf?hl=en) to avoid CORS issue, this usually happens if the server is using http protocol.


### Component structure
#### Components' names
- Control Components
  1. [src/components/ADCHeader.js](src/components/ADCHeader.js) \
     This is the single component of the blue header on top of the page.
  2. [src/components/AddRulePage.js](src/components/AddRulePage.js)
     1. [src/components/DayRangePicker.js](src/subcomponents/DayRangePicker.js) \
      This is the component for input day range.
     2. [src/subcomponents/AudienceAttributes.js](src/subcomponents/AudienceAttributes.js) \
     This is the component for selecting audience attributes.
     1. [src/components/CountDisplay.js](src/components/CountDisplay.js) \
     This is the component for the pie chart on right of the page
     1. The 'rules' panel is integrated inside AddRulePage.js
  3. [src/components/SegmentsPage.js](src/components/SegmentsPage.js)
     1. This is the single component for the segments page.
  4. [src/components/NotFoundPage.js](src/components/NotFoundPage.js)
     1. Static page for handling 404NotFound.
- Helper Components
  1. [src/routers/AppRouter.js](src/routers/AppRouter.js)
     - The router component for handling navigation between components
     - As it's the first components to be loaded, it also handles makeing a query to the server to get dimensions
  2. [src/subomponents/Loading.js](src/subcomponents/Loading.js)
      - The loading circle animation
  
### What's left
1. The publish to DFP button on segments page is still a place_holder
2. This application will need a user system including login/logout so that different information could be accessed by different level of use.

### How to hide an attribute's id?
Sometimes we want to pass an id to the backend, while display a human readable value at front-end, e.g. krux attribute. Luckily, we have an easy way to handle this.

1. In snowflake, for each value under this attribute, form it as: ```name + '|||||' + id```
      - ```'|||||'``` is the separator I defined in constants.js
2. In constants.js, add another constant for the field name of that attribute, make sure the value matches the value passed from back-end.
      - e.g.: ```export const KRUX_SEGMENT_FIELD_NAME = "audiencesegmentids";``` for krux segmentids.
3. In SegmentsPage.js, import the constant name, and in function ```getRulesFromSegment``` , go to the inner loop which loops through ```parsedRule[subidx]```, add one other ```else if(...){...}``` statement for detecting ```subidx.toLowerCase() === THE_CONSTANT_NAME_YOU_DEFINED```, and process values as the same for krux ids.
4. That's it!

### Deploy
1. ```ssh ec2-user@10.99.41.4```
2. in ssh: ```cd /www``` www is the production directory, www-dev is dev diretory, they have the same folder structure.
3. in ssh: ```./archive_build.sh``` this script compress the current build and put it into ./archive, and remove everything in ./build
4. local: ``` npm run build``` build the current version of adc tool locally
5. local: ```sftp ec2-user@10.99.41.4``` open sftp channel to pass files to server
6. in sftp: ```cd /www/build/```
7. in sftp: ```lcd ./build/```
8. in sftp: ```put -r ./*```
9. in ssh: ```sudo systemctl restart nginx``` restart front end host, and ```docker restart nginx_dev``` if you want to restart dev website
10. Visit adc.globeandmail.com to make sure the web is running